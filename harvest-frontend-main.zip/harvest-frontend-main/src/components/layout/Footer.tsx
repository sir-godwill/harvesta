import { Link } from 'react-router-dom';
import { 
  Facebook, 
  Twitter, 
  Instagram, 
  Linkedin,
  Mail,
  Phone,
  MapPin,
  Shield,
  CreditCard,
  Truck,
  HeadphonesIcon
} from 'lucide-react';
import { Separator } from '@/components/ui/separator';

export function Footer() {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    marketplace: [
      { label: 'Browse Products', href: '/' },
      { label: 'Categories', href: '/' },
      { label: 'Top Suppliers', href: '/' },
      { label: 'New Arrivals', href: '/' },
      { label: 'Deals & Discounts', href: '/' },
    ],
    forBuyers: [
      { label: 'How to Buy', href: '/' },
      { label: 'Buyer Protection', href: '/' },
      { label: 'Request Quotations', href: '/' },
      { label: 'Trade Assurance', href: '/' },
      { label: 'Logistics Services', href: '/' },
    ],
    forSuppliers: [
      { label: 'Sell on Harvestá', href: '/' },
      { label: 'Supplier Center', href: '/' },
      { label: 'Advertising', href: '/' },
      { label: 'Verified Supplier', href: '/' },
    ],
    support: [
      { label: 'Help Center', href: '/' },
      { label: 'Contact Us', href: '/' },
      { label: 'Report Abuse', href: '/' },
      { label: 'Submit Feedback', href: '/' },
    ],
  };

  const trustBadges = [
    { icon: Shield, label: 'Buyer Protection' },
    { icon: CreditCard, label: 'Secure Payment' },
    { icon: Truck, label: 'Fast Delivery' },
    { icon: HeadphonesIcon, label: '24/7 Support' },
  ];

  return (
    <footer className="bg-foreground text-background">
      {/* Trust Badges */}
      <div className="border-b border-background/10">
        <div className="container py-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {trustBadges.map((badge) => (
              <div key={badge.label} className="flex items-center gap-3">
                <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
                  <badge.icon className="w-6 h-6 text-primary" />
                </div>
                <span className="text-sm font-medium">{badge.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand Column */}
          <div className="lg:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center">
                <span className="text-white font-bold text-xl">H</span>
              </div>
              <span className="text-2xl font-bold text-primary">Harvestá</span>
            </Link>
            <p className="text-background/70 text-sm mb-4">
              Africa's leading B2B agro-commerce marketplace connecting farmers, 
              suppliers, and buyers across the continent.
            </p>
            <div className="space-y-2 text-sm text-background/70">
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4" />
                <span>support@harvesta.com</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4" />
                <span>+254 700 123 456</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                <span>Nairobi, Kenya</span>
              </div>
            </div>
          </div>

          {/* Links Columns */}
          <div>
            <h4 className="font-semibold mb-4">Marketplace</h4>
            <ul className="space-y-2">
              {footerLinks.marketplace.map((link) => (
                <li key={link.label}>
                  <Link 
                    to={link.href}
                    className="text-sm text-background/70 hover:text-primary transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">For Buyers</h4>
            <ul className="space-y-2">
              {footerLinks.forBuyers.map((link) => (
                <li key={link.label}>
                  <Link 
                    to={link.href}
                    className="text-sm text-background/70 hover:text-primary transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">For Suppliers</h4>
            <ul className="space-y-2">
              {footerLinks.forSuppliers.map((link) => (
                <li key={link.label}>
                  <Link 
                    to={link.href}
                    className="text-sm text-background/70 hover:text-primary transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Support</h4>
            <ul className="space-y-2">
              {footerLinks.support.map((link) => (
                <li key={link.label}>
                  <Link 
                    to={link.href}
                    className="text-sm text-background/70 hover:text-primary transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      <Separator className="bg-background/10" />

      {/* Bottom Footer */}
      <div className="container py-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-background/60">
            © {currentYear} Harvestá. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <Link to="/" className="text-background/60 hover:text-primary transition-colors">
              <Facebook className="w-5 h-5" />
            </Link>
            <Link to="/" className="text-background/60 hover:text-primary transition-colors">
              <Twitter className="w-5 h-5" />
            </Link>
            <Link to="/" className="text-background/60 hover:text-primary transition-colors">
              <Instagram className="w-5 h-5" />
            </Link>
            <Link to="/" className="text-background/60 hover:text-primary transition-colors">
              <Linkedin className="w-5 h-5" />
            </Link>
          </div>
          <div className="flex items-center gap-4 text-sm text-background/60">
            <Link to="/" className="hover:text-primary transition-colors">Privacy Policy</Link>
            <span>•</span>
            <Link to="/" className="hover:text-primary transition-colors">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
